<?php header('Location: /dist/cloud-reader/?epubs=..%2F..%2Fepub_content%2Flibrary.json'); ?>
