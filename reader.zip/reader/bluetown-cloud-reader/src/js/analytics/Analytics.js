define(function(){
    return{
        trackView : function(){},
        sendEvent : function(){}
    }
});