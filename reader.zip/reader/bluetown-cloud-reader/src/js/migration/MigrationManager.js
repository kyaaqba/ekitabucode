define(function(){

    return{
        checkIfNeedsMigration : function(callback){
            callback(false);
        }
    }
});